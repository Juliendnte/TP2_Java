package PTP_POO.PTP2.Vue;

import PTP_POO.PTP2.Model.ModeleTP2_1;

public interface IVue {
    void lancer();
}
