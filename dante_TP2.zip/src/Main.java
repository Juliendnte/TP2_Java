import PMenu.Menu;

public class Main {
    public static void main(String[] args) {
        Menu.execute();
    }
}